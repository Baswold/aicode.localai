"""
Main CLI interface for AiCode
Provides command-line interface and interactive shell
"""

import click
import os
import sys
from rich.console import Console
from rich.panel import Panel
from rich.text import Text

from .shell import InteractiveShell
from .config import Config
from .models import ModelManager

console = Console()

@click.group(invoke_without_command=True)
@click.option('--model', '-m', help='Specify model endpoint')
@click.option('--config', '-c', help='Config file path', default='config.ini')
@click.pass_context
def main(ctx, model, config):
    """AiCode - Resource-efficient CLI coding assistant for small local models"""
    
    # Initialize configuration
    config_manager = Config(config)
    
    # Display welcome banner
    welcome_text = Text("AiCode", style="bold cyan")
    welcome_text.append(" - CLI Coding Assistant", style="white")
    console.print(Panel(welcome_text, border_style="cyan"))
    
    if ctx.invoked_subcommand is None:
        # Start interactive shell
        shell = InteractiveShell(config_manager, model)
        shell.run()

@main.command()
@click.option('--config', '-c', help='Config file path', default='config.ini')
def configure(config):
    """Configure AiCode settings"""
    config_manager = Config(config)
    config_manager.interactive_setup()
    console.print("[green]Configuration updated successfully![/green]")

@main.command()
@click.option('--config', '-c', help='Config file path', default='config.ini')
def models(config):
    """List available models"""
    config_manager = Config(config)
    model_manager = ModelManager(config_manager)
    model_manager.list_models()

@main.command()
@click.argument('prompt')
@click.option('--model', '-m', help='Specify model endpoint')
@click.option('--config', '-c', help='Config file path', default='config.ini')
def ask(prompt, model, config):
    """Ask a single question to the model"""
    config_manager = Config(config)
    shell = InteractiveShell(config_manager, model)
    response = shell.process_single_prompt(prompt)
    console.print(response)

if __name__ == "__main__":
    main()
