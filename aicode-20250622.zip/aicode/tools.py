"""
Tool execution system for file operations, terminal commands, and code analysis
"""

import os
import subprocess
import ast
import json
from pathlib import Path
from typing import Dict, Any, List, Optional
from rich.console import Console
from rich.syntax import Syntax
from rich.panel import Panel
from rich.prompt import Confirm

console = Console()

class ToolExecutor:
    def __init__(self, config):
        self.config = config
        self.tool_config = config.get_tool_config()
        self.available_tools = self._initialize_tools()
    
    def _initialize_tools(self) -> Dict[str, callable]:
        """Initialize available tools based on configuration"""
        tools = {}
        
        if self.tool_config['enable_file_operations']:
            tools.update({
                'read_file': self.read_file,
                'write_file': self.write_file,
                'list_directory': self.list_directory,
                'create_directory': self.create_directory,
                'delete_file': self.delete_file,
                'file_exists': self.file_exists
            })
        
        if self.tool_config['enable_terminal_commands']:
            tools.update({
                'execute_command': self.execute_command,
                'get_working_directory': self.get_working_directory,
                'change_directory': self.change_directory
            })
        
        # Always available tools
        tools.update({
            'analyze_code': self.analyze_code,
            'format_code': self.format_code,
            'find_syntax_errors': self.find_syntax_errors
        })
        
        return tools
    
    def get_available_tools(self) -> List[str]:
        """Get list of available tool names"""
        return list(self.available_tools.keys())
    
    def execute_tool(self, tool_name: str, **kwargs) -> Dict[str, Any]:
        """Execute a tool with given parameters"""
        if tool_name not in self.available_tools:
            return {
                'success': False,
                'error': f"Tool '{tool_name}' not available or not enabled"
            }
        
        try:
            # Safety checks for dangerous operations
            if self.tool_config['safe_mode'] and self._is_dangerous_operation(tool_name, kwargs):
                if not self._confirm_dangerous_operation(tool_name, kwargs):
                    return {
                        'success': False,
                        'error': 'Operation cancelled by user'
                    }
            
            result = self.available_tools[tool_name](**kwargs)
            return {
                'success': True,
                'result': result
            }
        
        except Exception as e:
            return {
                'success': False,
                'error': str(e)
            }
    
    def _is_dangerous_operation(self, tool_name: str, kwargs: Dict) -> bool:
        """Check if operation is potentially dangerous"""
        dangerous_ops = {
            'delete_file': True,
            'execute_command': lambda k: any(cmd in k.get('command', '').lower() 
                                           for cmd in ['rm', 'del', 'format', 'sudo']),
            'write_file': lambda k: k.get('path', '').startswith('/') or '..' in k.get('path', '')
        }
        
        if tool_name in dangerous_ops:
            check = dangerous_ops[tool_name]
            return check(kwargs) if callable(check) else check
        
        return False
    
    def _confirm_dangerous_operation(self, tool_name: str, kwargs: Dict) -> bool:
        """Ask user to confirm dangerous operation"""
        console.print(f"[yellow]Warning: Potentially dangerous operation detected[/yellow]")
        console.print(f"Tool: {tool_name}")
        console.print(f"Parameters: {kwargs}")
        return Confirm.ask("Continue with this operation?", default=False)
    
    # File Operations
    def read_file(self, path: str) -> str:
        """Read content from a file"""
        try:
            with open(path, 'r', encoding='utf-8') as f:
                content = f.read()
            
            # Display syntax-highlighted content if it's code
            if self._is_code_file(path):
                syntax = Syntax(content, self._get_language_from_extension(path), 
                              theme="monokai", line_numbers=True)
                console.print(Panel(syntax, title=f"📄 {path}"))
            
            return content
        except Exception as e:
            raise Exception(f"Failed to read file '{path}': {e}")
    
    def write_file(self, path: str, content: str) -> str:
        """Write content to a file"""
        try:
            # Create directory if it doesn't exist
            os.makedirs(os.path.dirname(path), exist_ok=True)
            
            with open(path, 'w', encoding='utf-8') as f:
                f.write(content)
            
            console.print(f"[green]✓ File written: {path}[/green]")
            return f"Successfully wrote {len(content)} characters to {path}"
        except Exception as e:
            raise Exception(f"Failed to write file '{path}': {e}")
    
    def list_directory(self, path: str = ".") -> List[str]:
        """List contents of a directory"""
        try:
            items = []
            for item in sorted(os.listdir(path)):
                full_path = os.path.join(path, item)
                if os.path.isdir(full_path):
                    items.append(f"📁 {item}/")
                else:
                    items.append(f"📄 {item}")
            
            console.print(Panel("\n".join(items), title=f"📁 Directory: {path}"))
            return [item.split(' ', 1)[1] for item in items]
        except Exception as e:
            raise Exception(f"Failed to list directory '{path}': {e}")
    
    def create_directory(self, path: str) -> str:
        """Create a directory"""
        try:
            os.makedirs(path, exist_ok=True)
            console.print(f"[green]✓ Directory created: {path}[/green]")
            return f"Directory created: {path}"
        except Exception as e:
            raise Exception(f"Failed to create directory '{path}': {e}")
    
    def delete_file(self, path: str) -> str:
        """Delete a file"""
        try:
            os.remove(path)
            console.print(f"[red]✓ File deleted: {path}[/red]")
            return f"File deleted: {path}"
        except Exception as e:
            raise Exception(f"Failed to delete file '{path}': {e}")
    
    def file_exists(self, path: str) -> bool:
        """Check if a file exists"""
        return os.path.exists(path)
    
    # Terminal Operations
    def execute_command(self, command: str, timeout: int = 30) -> str:
        """Execute a terminal command"""
        try:
            console.print(f"[cyan]$ {command}[/cyan]")
            
            result = subprocess.run(
                command,
                shell=True,
                capture_output=True,
                text=True,
                timeout=timeout
            )
            
            output = ""
            if result.stdout:
                output += f"STDOUT:\n{result.stdout}\n"
            if result.stderr:
                output += f"STDERR:\n{result.stderr}\n"
            
            output += f"Return code: {result.returncode}"
            
            # Display output with syntax highlighting
            console.print(Panel(output, title="Command Output"))
            
            return output
        except subprocess.TimeoutExpired:
            raise Exception(f"Command timed out after {timeout} seconds")
        except Exception as e:
            raise Exception(f"Failed to execute command: {e}")
    
    def get_working_directory(self) -> str:
        """Get current working directory"""
        return os.getcwd()
    
    def change_directory(self, path: str) -> str:
        """Change working directory"""
        try:
            os.chdir(path)
            new_path = os.getcwd()
            console.print(f"[green]✓ Changed directory to: {new_path}[/green]")
            return f"Changed directory to: {new_path}"
        except Exception as e:
            raise Exception(f"Failed to change directory to '{path}': {e}")
    
    # Code Analysis
    def analyze_code(self, code: str, language: str = "python") -> Dict[str, Any]:
        """Analyze code for structure and potential issues"""
        analysis = {
            'lines': len(code.split('\n')),
            'characters': len(code),
            'language': language
        }
        
        if language.lower() == 'python':
            try:
                tree = ast.parse(code)
                analysis.update(self._analyze_python_ast(tree))
            except SyntaxError as e:
                analysis['syntax_error'] = str(e)
        
        return analysis
    
    def find_syntax_errors(self, code: str, language: str = "python") -> List[str]:
        """Find syntax errors in code"""
        errors = []
        
        if language.lower() == 'python':
            try:
                ast.parse(code)
            except SyntaxError as e:
                errors.append(f"Line {e.lineno}: {e.msg}")
        
        return errors
    
    def format_code(self, code: str, language: str = "python") -> str:
        """Format code (basic formatting)"""
        if language.lower() == 'python':
            # Basic Python formatting
            lines = code.split('\n')
            formatted_lines = []
            indent_level = 0
            
            for line in lines:
                stripped = line.strip()
                if not stripped:
                    formatted_lines.append('')
                    continue
                
                if stripped.endswith(':'):
                    formatted_lines.append('    ' * indent_level + stripped)
                    indent_level += 1
                elif stripped in ['else:', 'elif', 'except:', 'finally:']:
                    indent_level = max(0, indent_level - 1)
                    formatted_lines.append('    ' * indent_level + stripped)
                    indent_level += 1
                else:
                    formatted_lines.append('    ' * indent_level + stripped)
            
            return '\n'.join(formatted_lines)
        
        return code
    
    def _analyze_python_ast(self, tree: ast.AST) -> Dict[str, Any]:
        """Analyze Python AST for code metrics"""
        analyzer = {
            'functions': 0,
            'classes': 0,
            'imports': 0,
            'complexity': 0
        }
        
        for node in ast.walk(tree):
            if isinstance(node, ast.FunctionDef):
                analyzer['functions'] += 1
            elif isinstance(node, ast.ClassDef):
                analyzer['classes'] += 1
            elif isinstance(node, (ast.Import, ast.ImportFrom)):
                analyzer['imports'] += 1
            elif isinstance(node, (ast.If, ast.For, ast.While, ast.Try)):
                analyzer['complexity'] += 1
        
        return analyzer
    
    def _is_code_file(self, path: str) -> bool:
        """Check if file is a code file"""
        code_extensions = {'.py', '.js', '.ts', '.html', '.css', '.json', '.xml', '.yaml', '.yml'}
        return Path(path).suffix.lower() in code_extensions
    
    def _get_language_from_extension(self, path: str) -> str:
        """Get language name from file extension"""
        extension_map = {
            '.py': 'python',
            '.js': 'javascript',
            '.ts': 'typescript',
            '.html': 'html',
            '.css': 'css',
            '.json': 'json',
            '.xml': 'xml',
            '.yaml': 'yaml',
            '.yml': 'yaml'
        }
        return extension_map.get(Path(path).suffix.lower(), 'text')
