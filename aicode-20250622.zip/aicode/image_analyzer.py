"""
Image analysis capabilities for visual debugging and understanding
Optimized for small models with efficient image processing
"""

import base64
import io
from typing import Dict, Any, Optional
from PIL import Image, ImageDraw, ImageFont
from rich.console import Console

console = Console()

class ImageAnalyzer:
    def __init__(self, config):
        self.config = config
        self.max_image_size = (800, 600)  # Optimize for small models
        
    def analyze_image(self, image_path: str, analysis_type: str = "general") -> Dict[str, Any]:
        """Analyze an image file"""
        try:
            with Image.open(image_path) as img:
                # Basic image information
                analysis = {
                    'path': image_path,
                    'format': img.format,
                    'size': img.size,
                    'mode': img.mode,
                    'analysis_type': analysis_type
                }
                
                # Optimize image size for model processing
                optimized_img = self._optimize_image(img)
                
                # Convert to base64 for model processing
                analysis['base64'] = self._image_to_base64(optimized_img)
                
                # Add basic visual analysis
                analysis.update(self._basic_visual_analysis(optimized_img))
                
                console.print(f"[green]✓ Image analyzed: {image_path}[/green]")
                console.print(f"Size: {img.size}, Format: {img.format}, Mode: {img.mode}")
                
                return analysis
                
        except Exception as e:
            console.print(f"[red]Error analyzing image: {e}[/red]")
            return {'error': str(e)}
    
    def create_visual_explanation(self, description: str, width: int = 400, 
                                height: int = 300) -> str:
        """Create a simple visual explanation image"""
        try:
            # Create a new image with white background
            img = Image.new('RGB', (width, height), 'white')
            draw = ImageDraw.Draw(img)
            
            # Try to use a default font
            try:
                font = ImageFont.truetype("arial.ttf", 16)
            except:
                font = ImageFont.load_default()
            
            # Add text to image
            lines = self._wrap_text(description, width - 40)
            y_position = 20
            
            for line in lines:
                draw.text((20, y_position), line, fill='black', font=font)
                y_position += 25
                if y_position > height - 30:
                    break
            
            # Add a simple border
            draw.rectangle([0, 0, width-1, height-1], outline='gray', width=2)
            
            # Convert to base64
            base64_img = self._image_to_base64(img)
            
            console.print(f"[green]✓ Visual explanation created[/green]")
            return base64_img
            
        except Exception as e:
            console.print(f"[red]Error creating visual explanation: {e}[/red]")
            return ""
    
    def extract_text_regions(self, image_path: str) -> Dict[str, Any]:
        """Extract potential text regions from image (basic implementation)"""
        try:
            with Image.open(image_path) as img:
                # Convert to grayscale for text detection
                gray_img = img.convert('L')
                
                # Basic edge detection simulation
                # This is a simplified approach - in production you'd use OCR libraries
                analysis = {
                    'image_path': image_path,
                    'text_regions_detected': True,
                    'method': 'basic_analysis',
                    'recommendations': [
                        'Use OCR library like pytesseract for actual text extraction',
                        'Consider preprocessing image for better text recognition',
                        'Adjust image contrast and brightness if needed'
                    ]
                }
                
                console.print(f"[yellow]ℹ Basic text region analysis completed[/yellow]")
                return analysis
                
        except Exception as e:
            console.print(f"[red]Error extracting text regions: {e}[/red]")
            return {'error': str(e)}
    
    def compare_images(self, image1_path: str, image2_path: str) -> Dict[str, Any]:
        """Compare two images for differences"""
        try:
            with Image.open(image1_path) as img1, Image.open(image2_path) as img2:
                # Resize images to same size for comparison
                size = (min(img1.width, img2.width), min(img1.height, img2.height))
                img1_resized = img1.resize(size)
                img2_resized = img2.resize(size)
                
                # Basic comparison
                comparison = {
                    'image1': image1_path,
                    'image2': image2_path,
                    'size_match': img1.size == img2.size,
                    'format_match': img1.format == img2.format,
                    'mode_match': img1.mode == img2.mode,
                    'dimensions': {
                        'image1': img1.size,
                        'image2': img2.size
                    }
                }
                
                # Create difference visualization (simplified)
                if img1.mode == img2.mode:
                    # Basic pixel difference detection
                    pixels1 = list(img1_resized.getdata())
                    pixels2 = list(img2_resized.getdata())
                    
                    differences = sum(1 for p1, p2 in zip(pixels1, pixels2) if p1 != p2)
                    total_pixels = len(pixels1)
                    
                    comparison['pixel_differences'] = differences
                    comparison['difference_percentage'] = (differences / total_pixels) * 100
                    comparison['are_identical'] = differences == 0
                
                console.print(f"[green]✓ Image comparison completed[/green]")
                return comparison
                
        except Exception as e:
            console.print(f"[red]Error comparing images: {e}[/red]")
            return {'error': str(e)}
    
    def _optimize_image(self, img: Image.Image) -> Image.Image:
        """Optimize image size and quality for model processing"""
        # Resize if too large
        if img.size[0] > self.max_image_size[0] or img.size[1] > self.max_image_size[1]:
            img.thumbnail(self.max_image_size, Image.Resampling.LANCZOS)
        
        # Convert to RGB if needed
        if img.mode not in ['RGB', 'L']:
            img = img.convert('RGB')
        
        return img
    
    def _image_to_base64(self, img: Image.Image) -> str:
        """Convert PIL Image to base64 string"""
        buffer = io.BytesIO()
        img.save(buffer, format='PNG')
        img_bytes = buffer.getvalue()
        return base64.b64encode(img_bytes).decode('utf-8')
    
    def _basic_visual_analysis(self, img: Image.Image) -> Dict[str, Any]:
        """Perform basic visual analysis of image"""
        analysis = {}
        
        # Color analysis
        if img.mode == 'RGB':
            colors = img.getcolors(maxcolors=256*256*256)
            if colors:
                analysis['dominant_colors'] = len(colors)
                analysis['most_common_color'] = colors[0][1] if colors else None
        
        # Basic complexity estimation
        if img.mode == 'L':  # Grayscale
            pixels = list(img.getdata())
            unique_values = len(set(pixels))
            analysis['grayscale_complexity'] = unique_values / 256
        
        # Image characteristics
        aspect_ratio = img.width / img.height
        analysis['aspect_ratio'] = round(aspect_ratio, 2)
        analysis['is_square'] = abs(aspect_ratio - 1.0) < 0.1
        analysis['is_landscape'] = aspect_ratio > 1.2
        analysis['is_portrait'] = aspect_ratio < 0.8
        
        return analysis
    
    def _wrap_text(self, text: str, max_width: int) -> list:
        """Wrap text to fit within specified width"""
        words = text.split()
        lines = []
        current_line = []
        current_length = 0
        
        for word in words:
            word_length = len(word) * 8  # Approximate character width
            if current_length + word_length < max_width:
                current_line.append(word)
                current_length += word_length + 8  # Space
            else:
                if current_line:
                    lines.append(' '.join(current_line))
                current_line = [word]
                current_length = word_length
        
        if current_line:
            lines.append(' '.join(current_line))
        
        return lines
