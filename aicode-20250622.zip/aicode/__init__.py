"""
AiCode - CLI coding assistant optimized for small local models
"""

__version__ = "1.0.0"
__author__ = "AiCode Team"
