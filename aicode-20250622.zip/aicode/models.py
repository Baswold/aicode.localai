"""
Model management and API communication
Handles communication with various local model servers
"""

import requests
import json
from typing import Dict, Any, Optional
from rich.console import Console
from rich.table import Table
from rich.panel import Panel

from .config import Config

console = Console()

class ModelManager:
    def __init__(self, config: Config):
        self.config = config
        self.current_model = None
        self.session = requests.Session()
        
    def set_model(self, model_name: str):
        """Set the current model"""
        endpoint = self.config.get_model_endpoint(model_name)
        if endpoint:
            self.current_model = model_name
            console.print(f"[green]Switched to model: {model_name}[/green]")
            return True
        else:
            console.print(f"[red]Model '{model_name}' not found in configuration[/red]")
            return False
    
    def get_current_endpoint(self):
        """Get current model endpoint"""
        if self.current_model:
            return self.config.get_model_endpoint(self.current_model)
        return self.config.get_model_endpoint()
    
    def test_connection(self, model_name: str = None) -> bool:
        """Test connection to model endpoint"""
        endpoint = self.config.get_model_endpoint(model_name) if model_name else self.get_current_endpoint()
        
        try:
            # Try to ping the endpoint
            response = self.session.get(endpoint.replace('/chat/completions', '/models').replace('/api/chat', '/api/tags'), 
                                      timeout=5)
            return response.status_code == 200
        except requests.RequestException:
            return False
    
    def list_models(self):
        """List all configured models with status"""
        table = Table(title="Available Models")
        table.add_column("Name", style="cyan")
        table.add_column("Endpoint", style="white")
        table.add_column("Status", style="green")
        table.add_column("Current", style="yellow")
        
        for name, endpoint in self.config.config['models'].items():
            status = "✓ Online" if self.test_connection(name) else "✗ Offline"
            current = "●" if name == self.current_model else ""
            table.add_row(name, endpoint, status, current)
        
        console.print(table)
    
    def send_request(self, messages: list, stream: bool = False) -> Optional[Dict[Any, Any]]:
        """Send request to current model"""
        endpoint = self.get_current_endpoint()
        if not endpoint:
            console.print("[red]No model endpoint configured[/red]")
            return None
        
        model_config = self.config.get_model_config()
        
        # Prepare request based on endpoint type
        if 'ollama' in endpoint.lower():
            payload = self._prepare_ollama_payload(messages, model_config, stream)
        else:
            payload = self._prepare_openai_payload(messages, model_config, stream)
        
        try:
            response = self.session.post(
                endpoint,
                json=payload,
                timeout=model_config['timeout'],
                stream=stream
            )
            response.raise_for_status()
            
            if stream:
                return response
            else:
                return response.json()
                
        except requests.RequestException as e:
            console.print(f"[red]Error communicating with model: {e}[/red]")
            return None
    
    def _prepare_openai_payload(self, messages: list, config: Dict, stream: bool) -> Dict:
        """Prepare OpenAI-compatible payload"""
        return {
            "model": "local-model",
            "messages": messages,
            "max_tokens": config['max_tokens'],
            "temperature": config['temperature'],
            "stream": stream
        }
    
    def _prepare_ollama_payload(self, messages: list, config: Dict, stream: bool) -> Dict:
        """Prepare Ollama-compatible payload"""
        return {
            "model": "local-model",
            "messages": messages,
            "options": {
                "num_predict": config['max_tokens'],
                "temperature": config['temperature']
            },
            "stream": stream
        }
    
    def extract_response_content(self, response_data: Dict) -> str:
        """Extract content from model response"""
        try:
            # Handle OpenAI format
            if 'choices' in response_data:
                return response_data['choices'][0]['message']['content']
            
            # Handle Ollama format
            elif 'message' in response_data:
                return response_data['message']['content']
            
            # Handle other formats
            elif 'content' in response_data:
                return response_data['content']
            
            else:
                return str(response_data)
                
        except (KeyError, IndexError) as e:
            console.print(f"[red]Error parsing response: {e}[/red]")
            return "Error parsing model response"
