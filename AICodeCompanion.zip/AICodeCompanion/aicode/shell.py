"""
Interactive shell interface for AiCode
Handles user interaction, command processing, and session management
"""

import re
from typing import Dict, List, Optional, Any
from rich.console import Console
from rich.prompt import Prompt
from rich.panel import Panel
from rich.markdown import Markdown
from rich.table import Table
from rich.live import Live
from rich.spinner import Spinner
from prompt_toolkit import prompt
from prompt_toolkit.history import InMemoryHistory
from prompt_toolkit.completion import WordCompleter

from .models import ModelManager
from .tools import ToolExecutor
from .prompts import PromptOptimizer
from .image_analyzer import ImageAnalyzer

console = Console()

class InteractiveShell:
    def __init__(self, config, model_name=None):
        self.config = config
        self.model_manager = ModelManager(config)
        self.tool_executor = ToolExecutor(config)
        self.prompt_optimizer = PromptOptimizer()
        self.image_analyzer = ImageAnalyzer(config)
        
        # Built-in engines (simplified)
        self.debug_engine = {'error_history': [], 'breakpoints': []}
        self.planning_engine = {'plans': {}, 'current_plan': None}
        self.theme_manager = {
            'themes': {
                "default": {"primary": "cyan", "success": "green", "warning": "yellow", "error": "red"},
                "dark": {"primary": "bright_magenta", "success": "bright_green", "warning": "bright_yellow", "error": "bright_red"},
                "ocean": {"primary": "bright_blue", "success": "bright_cyan", "warning": "bright_yellow", "error": "bright_red"}
            },
            'current': 'default'
        }
        self.sessions = {}
        
        # Session state
        self.conversation_history = []
        self.context = []
        self.current_directory = "."
        
        # Command completion
        self.commands = [
            '/help', '/models', '/switch', '/tools', '/clear', '/history',
            '/context', '/image', '/debug', '/analyze', '/exit', '/quit',
            '/edit-context', '/add-tool', '/plan', '/theme', '/save-session',
            '/load-session', '/export', '/import', '/status', '/config'
        ]
        self.completer = WordCompleter(self.commands)
        self.history = InMemoryHistory()
        
        # Load aicode.md context if available
        self._load_aicode_context()
        
        # Set initial model
        if model_name:
            self.model_manager.set_model(model_name)
    
    def _load_aicode_context(self):
        """Load aicode.md context file if available"""
        try:
            import os
            context_path = "aicode.md"
            if os.path.exists(context_path):
                with open(context_path, 'r', encoding='utf-8') as f:
                    aicode_context = f.read()
                    self.context.append({
                        'type': 'system_context',
                        'source': 'aicode.md',
                        'content': aicode_context[:2000]  # Truncate for small models
                    })
                console.print("[green]✓ Loaded AiCode context[/green]")
        except Exception as e:
            # Silent fail - context loading is optional
            pass
    
    def run(self):
        """Start the interactive shell"""
        console.print("[bold green]AiCode Interactive Shell[/bold green]")
        console.print("Type '/help' for commands or start coding!")
        console.print(f"Model: {self.model_manager.current_model or 'default'}")
        console.print("")
        
        while True:
            try:
                # Get user input with completion
                user_input = prompt(
                    "aicode> ",
                    history=self.history,
                    completer=self.completer
                ).strip()
                
                if not user_input:
                    continue
                
                # Handle commands
                if user_input.startswith('/'):
                    if not self.handle_command(user_input):
                        break
                else:
                    # Process as conversation
                    self.process_conversation(user_input)
                    
            except (EOFError, KeyboardInterrupt):
                console.print("\n[yellow]Goodbye![/yellow]")
                break
            except Exception as e:
                console.print(f"[red]Error: {e}[/red]")
    
    def handle_command(self, command: str) -> bool:
        """Handle shell commands. Returns False to exit."""
        parts = command.split()
        cmd = parts[0].lower()
        
        if cmd in ['/exit', '/quit']:
            return False
        
        elif cmd == '/help':
            self.show_help()
        
        elif cmd == '/models':
            self.model_manager.list_models()
        
        elif cmd == '/switch':
            if len(parts) > 1:
                self.model_manager.set_model(parts[1])
            else:
                model_name = Prompt.ask("Enter model name")
                self.model_manager.set_model(model_name)
        
        elif cmd == '/tools':
            self.show_available_tools()
        
        elif cmd == '/clear':
            self.conversation_history.clear()
            self.context.clear()
            console.print("[green]Conversation cleared[/green]")
        
        elif cmd == '/history':
            self.show_conversation_history()
        
        elif cmd == '/context':
            self.show_context()
        
        elif cmd == '/image':
            if len(parts) > 1:
                self.analyze_image(parts[1])
            else:
                image_path = Prompt.ask("Enter image path")
                self.analyze_image(image_path)
        
        elif cmd == '/debug':
            self.debug_mode()
        
        elif cmd == '/analyze':
            if len(parts) > 1:
                self.analyze_file(parts[1])
            else:
                file_path = Prompt.ask("Enter file path to analyze")
                self.analyze_file(file_path)
        
        elif cmd == '/edit-context':
            self.edit_context_file()
        
        elif cmd == '/add-tool':
            self.add_custom_tool()
        
        elif cmd == '/plan':
            if len(parts) > 1:
                self.create_plan(' '.join(parts[1:]))
            else:
                task = Prompt.ask("Enter task to plan")
                self.create_plan(task)
        
        elif cmd == '/theme':
            if len(parts) > 1:
                self.change_theme(parts[1])
            else:
                self.show_themes()
        
        elif cmd == '/save-session':
            if len(parts) > 1:
                self.save_session(parts[1])
            else:
                self.save_session()
        
        elif cmd == '/load-session':
            if len(parts) > 1:
                self.load_session(parts[1])
            else:
                self.list_sessions()
        
        elif cmd == '/status':
            self.show_status()
        
        elif cmd == '/config':
            self.show_config()
        
        else:
            console.print(f"[red]Unknown command: {cmd}[/red]")
            console.print("Type '/help' for available commands")
        
        return True
    
    def process_conversation(self, user_input: str):
        """Process user input as conversation"""
        # Check for tool usage patterns
        tool_calls = self.extract_tool_calls(user_input)
        
        if tool_calls:
            self.execute_tools_and_respond(user_input, tool_calls)
        else:
            self.generate_response(user_input)
    
    def process_single_prompt(self, prompt: str) -> str:
        """Process a single prompt without interactive session"""
        messages = self.prompt_optimizer.optimize_for_small_model(prompt, self.context)
        
        with console.status("[bold green]Thinking..."):
            response_data = self.model_manager.send_request(messages)
        
        if response_data:
            response = self.model_manager.extract_response_content(response_data)
            return response
        else:
            return "Error: Could not get response from model"
    
    def generate_response(self, user_input: str):
        """Generate response from model"""
        # Determine prompt type and optimize
        if any(word in user_input.lower() for word in ['write', 'create', 'code']):
            messages = self.prompt_optimizer.create_coding_prompt(user_input, context=self.get_recent_context())
        elif any(word in user_input.lower() for word in ['error', 'debug', 'fix']):
            messages = self.prompt_optimizer.create_debugging_prompt(user_input, context=self.get_recent_context())
        elif 'analyze' in user_input.lower():
            messages = self.prompt_optimizer.create_analysis_prompt(user_input)
        else:
            messages = self.prompt_optimizer.optimize_for_small_model(user_input, self.context)
        
        # Add conversation history
        if self.conversation_history:
            recent_history = self.conversation_history[-3:]  # Last 3 exchanges
            for exchange in recent_history:
                messages.insert(-1, {"role": "user", "content": exchange['user']})
                messages.insert(-1, {"role": "assistant", "content": exchange['assistant']})
        
        # Generate response with loading indicator
        with Live(Spinner("dots", text="[bold green]Generating response..."), console=console):
            response_data = self.model_manager.send_request(messages)
        
        if response_data:
            response = self.model_manager.extract_response_content(response_data)
            
            # Display response
            self.display_response(response)
            
            # Store in conversation history
            self.conversation_history.append({
                'user': user_input,
                'assistant': response
            })
            
            # Extract and execute any tool calls in response
            self.check_and_execute_tools(response)
        else:
            console.print("[red]Error: Could not get response from model[/red]")
    
    def extract_tool_calls(self, text: str) -> List[Dict[str, Any]]:
        """Extract tool calls from text"""
        tool_pattern = r'TOOL:\s*(\w+)\((.*?)\)'
        matches = re.findall(tool_pattern, text)
        
        tool_calls = []
        for tool_name, params_str in matches:
            try:
                # Parse parameters (simple parsing)
                params = {}
                if params_str.strip():
                    for param in params_str.split(','):
                        if '=' in param:
                            key, value = param.split('=', 1)
                            key = key.strip().strip('"\'')
                            value = value.strip().strip('"\'')
                            params[key] = value
                
                tool_calls.append({
                    'name': tool_name,
                    'params': params
                })
            except Exception as e:
                console.print(f"[red]Error parsing tool call: {e}[/red]")
        
        return tool_calls
    
    def execute_tools_and_respond(self, user_input: str, tool_calls: List[Dict]):
        """Execute tools and generate response"""
        tool_results = []
        
        for tool_call in tool_calls:
            result = self.tool_executor.execute_tool(tool_call['name'], **tool_call['params'])
            tool_results.append({
                'tool': tool_call['name'],
                'params': tool_call['params'],
                'result': result
            })
        
        # Create prompt with tool results
        available_tools = self.tool_executor.get_available_tools()
        messages = self.prompt_optimizer.create_tool_usage_prompt(available_tools, user_input)
        
        # Add tool results to context
        tool_context = "Tool execution results:\n"
        for result in tool_results:
            if result['result']['success']:
                tool_context += f"✓ {result['tool']}: {result['result']['result']}\n"
            else:
                tool_context += f"✗ {result['tool']}: {result['result']['error']}\n"
        
        messages.append({
            "role": "system",
            "content": tool_context
        })
        
        # Generate response
        self.generate_response_from_messages(messages)
    
    def check_and_execute_tools(self, response: str):
        """Check response for tool calls and execute them"""
        tool_calls = self.extract_tool_calls(response)
        
        if tool_calls:
            console.print("[yellow]Executing suggested tools...[/yellow]")
            for tool_call in tool_calls:
                result = self.tool_executor.execute_tool(tool_call['name'], **tool_call['params'])
                if result['success']:
                    self.context.append({
                        'type': 'tool_execution',
                        'tool': tool_call['name'],
                        'result': result['result']
                    })
    
    def generate_response_from_messages(self, messages: List[Dict]):
        """Generate response from prepared messages"""
        with Live(Spinner("dots", text="[bold green]Processing..."), console=console):
            response_data = self.model_manager.send_request(messages)
        
        if response_data:
            response = self.model_manager.extract_response_content(response_data)
            self.display_response(response)
        else:
            console.print("[red]Error: Could not get response from model[/red]")
    
    def display_response(self, response: str):
        """Display model response with formatting"""
        if '```' in response:
            # Response contains code blocks
            console.print(Markdown(response))
        else:
            # Regular text response
            console.print(Panel(response, border_style="blue", title="Response"))
    
    def show_help(self):
        """Display help information"""
        help_table = Table(title="AiCode Commands")
        help_table.add_column("Command", style="cyan")
        help_table.add_column("Description", style="white")
        
        commands = [
            ("/help", "Show this help message"),
            ("/models", "List available models"),
            ("/switch <model>", "Switch to a different model"),
            ("/tools", "Show available tools"),
            ("/clear", "Clear conversation history"),
            ("/history", "Show conversation history"),
            ("/context", "Show current context"),
            ("/image <path>", "Analyze an image"),
            ("/debug", "Enter debug mode"),
            ("/analyze <file>", "Analyze a code file"),
            ("/exit, /quit", "Exit AiCode")
        ]
        
        for cmd, desc in commands:
            help_table.add_row(cmd, desc)
        
        console.print(help_table)
        
        console.print("\n[yellow]Tips:[/yellow]")
        console.print("• Ask coding questions naturally")
        console.print("• Request file operations, code analysis, or debugging help")
        console.print("• Use TOOL: syntax to explicitly call tools")
        console.print("• Images can be analyzed for visual debugging")
    
    def show_available_tools(self):
        """Show available tools"""
        tools = self.tool_executor.get_available_tools()
        
        tool_table = Table(title="Available Tools")
        tool_table.add_column("Tool", style="cyan")
        tool_table.add_column("Category", style="yellow")
        
        tool_categories = {
            'read_file': 'File Operations',
            'write_file': 'File Operations',
            'list_directory': 'File Operations',
            'create_directory': 'File Operations',
            'delete_file': 'File Operations',
            'file_exists': 'File Operations',
            'execute_command': 'Terminal',
            'get_working_directory': 'Terminal',
            'change_directory': 'Terminal',
            'analyze_code': 'Code Analysis',
            'format_code': 'Code Analysis',
            'find_syntax_errors': 'Code Analysis'
        }
        
        for tool in tools:
            category = tool_categories.get(tool, 'Other')
            tool_table.add_row(tool, category)
        
        console.print(tool_table)
    
    def show_conversation_history(self):
        """Show conversation history"""
        if not self.conversation_history:
            console.print("[yellow]No conversation history[/yellow]")
            return
        
        for i, exchange in enumerate(self.conversation_history[-5:], 1):
            console.print(f"\n[bold cyan]Exchange {i}:[/bold cyan]")
            console.print(f"[green]User:[/green] {exchange['user']}")
            console.print(f"[blue]Assistant:[/blue] {exchange['assistant'][:200]}{'...' if len(exchange['assistant']) > 200 else ''}")
    
    def show_context(self):
        """Show current context"""
        if not self.context:
            console.print("[yellow]No context available[/yellow]")
            return
        
        context_table = Table(title="Current Context")
        context_table.add_column("Type", style="cyan")
        context_table.add_column("Details", style="white")
        
        for item in self.context[-10:]:  # Show last 10 context items
            item_type = item.get('type', 'unknown')
            details = str(item).replace(item_type, '').strip()[:100]
            context_table.add_row(item_type, details)
        
        console.print(context_table)
    
    def analyze_image(self, image_path: str):
        """Analyze an image"""
        result = self.image_analyzer.analyze_image(image_path)
        
        if 'error' not in result:
            self.context.append({
                'type': 'image_analysis',
                'path': image_path,
                'analysis': result
            })
            
            # Generate AI response about the image
            prompt = f"I've analyzed the image at {image_path}. It's a {result.get('format', 'unknown')} image with size {result.get('size', 'unknown')}. What would you like to know about this image?"
            self.generate_response(prompt)
    
    def analyze_file(self, file_path: str):
        """Analyze a code file"""
        try:
            content = self.tool_executor.read_file(file_path)
            analysis = self.tool_executor.analyze_code(content)
            
            self.context.append({
                'type': 'file_analysis',
                'path': file_path,
                'analysis': analysis
            })
            
            # Generate AI response about the file
            messages = self.prompt_optimizer.create_analysis_prompt(content)
            self.generate_response_from_messages(messages)
            
        except Exception as e:
            console.print(f"[red]Error analyzing file: {e}[/red]")
    
    def debug_mode(self):
        """Enter interactive debug mode"""
        console.print("[yellow]Debug mode - Enter error message or code to debug[/yellow]")
        console.print("Type 'exit' to leave debug mode")
        
        while True:
            debug_input = Prompt.ask("debug", default="").strip()
            
            if debug_input.lower() == 'exit':
                break
            
            if debug_input:
                messages = self.prompt_optimizer.create_debugging_prompt(debug_input)
                self.generate_response_from_messages(messages)
    
    def get_recent_context(self) -> str:
        """Get recent context as string"""
        if not self.context:
            return ""
        
        recent = self.context[-3:]
        context_str = ""
        
        for item in recent:
            if item.get('type') == 'file_analysis':
                context_str += f"File: {item.get('path', 'unknown')}\n"
            elif item.get('type') == 'tool_execution':
                context_str += f"Tool: {item.get('tool', 'unknown')}\n"
        
        return context_str
    
    # Advanced Features Implementation
    
    def edit_context_file(self):
        """Edit the aicode.md context file"""
        context_file = "aicode.md"
        
        if not os.path.exists(context_file):
            console.print("[yellow]Creating new aicode.md file[/yellow]")
            with open(context_file, 'w') as f:
                f.write("# AiCode Context\n\nAdd your project context here...\n")
        
        console.print(f"[cyan]Edit {context_file} in your preferred editor, then press Enter[/cyan]")
        input("Press Enter when done editing...")
        self._load_aicode_context()
    
    def add_custom_tool(self):
        """Add a custom tool to the system"""
        console.print("[cyan]Add Custom Tool[/cyan]")
        
        tool_name = Prompt.ask("Tool name")
        tool_description = Prompt.ask("Tool description")
        tool_command = Prompt.ask("Shell command to execute")
        
        if not all([tool_name, tool_description, tool_command]):
            console.print("[red]All fields are required[/red]")
            return
        
        # Store custom tool info
        custom_tools_file = "custom_tools.json"
        try:
            import json
            tools_data = {}
            if os.path.exists(custom_tools_file):
                with open(custom_tools_file, 'r') as f:
                    tools_data = json.load(f)
            
            tools_data[tool_name] = {
                'description': tool_description,
                'command': tool_command
            }
            
            with open(custom_tools_file, 'w') as f:
                json.dump(tools_data, f, indent=2)
            
            console.print(f"[green]Added custom tool '{tool_name}'[/green]")
        except Exception as e:
            console.print(f"[red]Error saving tool: {e}[/red]")
    
    def create_plan(self, task: str):
        """Create a project plan"""
        plan_id = f"plan_{len(self.planning_engine['plans']) + 1}"
        
        # Simple task breakdown
        phases = [
            {"name": "Planning", "tasks": ["Analyze requirements", "Design structure"], "hours": 2},
            {"name": "Implementation", "tasks": ["Core functionality", "Error handling"], "hours": 6},
            {"name": "Testing", "tasks": ["Unit tests", "Integration tests"], "hours": 2}
        ]
        
        plan = {
            'task': task,
            'phases': phases,
            'total_hours': sum(p['hours'] for p in phases),
            'status': 'created'
        }
        
        self.planning_engine['plans'][plan_id] = plan
        self.planning_engine['current_plan'] = plan_id
        
        # Display plan
        console.print(f"[bold cyan]Plan Created: {task}[/bold cyan]")
        table = Table(title="Project Phases")
        table.add_column("Phase", style="cyan")
        table.add_column("Tasks", style="white")
        table.add_column("Hours", style="yellow")
        
        for phase in phases:
            table.add_row(phase['name'], ', '.join(phase['tasks']), str(phase['hours']))
        
        console.print(table)
        console.print(f"[bold]Total estimated time: {plan['total_hours']} hours[/bold]")
    
    def change_theme(self, theme_name: str):
        """Change the color theme"""
        themes = self.theme_manager['themes']
        
        if theme_name in themes:
            self.theme_manager['current'] = theme_name
            theme = themes[theme_name]
            console.print(f"[{theme['success']}]✓ Changed to {theme_name} theme[/{theme['success']}]")
        else:
            console.print(f"[red]Theme '{theme_name}' not found[/red]")
    
    def show_themes(self):
        """Show available themes"""
        console.print("[bold cyan]Available Themes[/bold cyan]")
        
        themes = self.theme_manager['themes']
        current = self.theme_manager['current']
        
        for name, colors in themes.items():
            is_current = " (current)" if name == current else ""
            console.print(f"[{colors['primary']}]• {name}{is_current}[/{colors['primary']}]")
            console.print(f"  Sample: [{colors['success']}]Success[/{colors['success']}] "
                         f"[{colors['warning']}]Warning[/{colors['warning']}] "
                         f"[{colors['error']}]Error[/{colors['error']}]")
    
    def save_session(self, name: str = None):
        """Save current session"""
        if not name:
            from datetime import datetime
            name = f"session_{datetime.now().strftime('%Y%m%d_%H%M')}"
        
        session_data = {
            'conversation_history': self.conversation_history,
            'context': self.context,
            'current_model': self.model_manager.current_model,
            'theme': self.theme_manager['current']
        }
        
        self.sessions[name] = session_data
        
        # Save to file
        try:
            import json
            sessions_file = "sessions.json"
            all_sessions = {}
            
            if os.path.exists(sessions_file):
                with open(sessions_file, 'r') as f:
                    all_sessions = json.load(f)
            
            all_sessions[name] = session_data
            
            with open(sessions_file, 'w') as f:
                json.dump(all_sessions, f, indent=2)
            
            console.print(f"[green]Session saved as '{name}'[/green]")
        except Exception as e:
            console.print(f"[red]Error saving session: {e}[/red]")
    
    def load_session(self, name: str):
        """Load a saved session"""
        try:
            import json
            sessions_file = "sessions.json"
            
            if os.path.exists(sessions_file):
                with open(sessions_file, 'r') as f:
                    all_sessions = json.load(f)
                
                if name in all_sessions:
                    session_data = all_sessions[name]
                    self.conversation_history = session_data.get('conversation_history', [])
                    self.context = session_data.get('context', [])
                    
                    # Restore model if available
                    if 'current_model' in session_data:
                        self.model_manager.set_model(session_data['current_model'])
                    
                    # Restore theme
                    if 'theme' in session_data:
                        self.theme_manager['current'] = session_data['theme']
                    
                    console.print(f"[green]Session '{name}' loaded[/green]")
                else:
                    console.print(f"[red]Session '{name}' not found[/red]")
            else:
                console.print("[yellow]No saved sessions found[/yellow]")
        except Exception as e:
            console.print(f"[red]Error loading session: {e}[/red]")
    
    def list_sessions(self):
        """List all saved sessions"""
        try:
            import json
            sessions_file = "sessions.json"
            
            if os.path.exists(sessions_file):
                with open(sessions_file, 'r') as f:
                    all_sessions = json.load(f)
                
                if all_sessions:
                    console.print("[cyan]Saved Sessions:[/cyan]")
                    for name in all_sessions.keys():
                        console.print(f"  • {name}")
                    console.print(f"\nUse '/load-session <name>' to load a session")
                else:
                    console.print("[yellow]No saved sessions[/yellow]")
            else:
                console.print("[yellow]No saved sessions found[/yellow]")
        except Exception as e:
            console.print(f"[red]Error listing sessions: {e}[/red]")
    
    def show_status(self):
        """Show system status"""
        console.print("[bold cyan]AiCode Status[/bold cyan]")
        
        # Model status
        console.print(f"[green]Model:[/green] {self.model_manager.current_model}")
        is_connected = self.model_manager.test_connection()
        status = "Connected" if is_connected else "Disconnected"
        color = "green" if is_connected else "red"
        console.print(f"[green]Connection:[/green] [{color}]{status}[/{color}]")
        
        # Theme status
        console.print(f"[green]Theme:[/green] {self.theme_manager['current']}")
        
        # Context status
        context_status = f"{len(self.context)} lines loaded" if self.context else "No context loaded"
        console.print(f"[green]Context:[/green] {context_status}")
        
        # Session status
        history_count = len(self.conversation_history)
        console.print(f"[green]History:[/green] {history_count} exchanges")
        
        # Available tools
        tools = self.tool_executor.get_available_tools()
        console.print(f"[green]Tools:[/green] {len(tools)} available")
    
    def show_config(self):
        """Show current configuration"""
        console.print("[bold cyan]AiCode Configuration[/bold cyan]")
        
        # Display config sections
        try:
            config_dict = {
                'models': dict(self.config.config['models']) if 'models' in self.config.config else {},
                'settings': dict(self.config.config['settings']) if 'settings' in self.config.config else {},
                'tools': dict(self.config.config['tools']) if 'tools' in self.config.config else {}
            }
            
            for section, items in config_dict.items():
                if items:
                    console.print(f"\n[yellow]{section.upper()}:[/yellow]")
                    for key, value in items.items():
                        # Hide sensitive values
                        if any(secret in key.lower() for secret in ['key', 'token', 'password']):
                            value = "***"
                        console.print(f"  {key}: {value}")
        except Exception as e:
            console.print(f"[red]Error reading config: {e}[/red]")
