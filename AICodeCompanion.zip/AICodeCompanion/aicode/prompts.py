"""
Optimized prompt templates for small local models
Smart prompt engineering to maximize performance with limited resources
"""

from typing import Dict, List, Any, Optional
from datetime import datetime

class PromptOptimizer:
    def __init__(self):
        self.system_prompts = {
            'default': self._get_default_system_prompt(),
            'coding': self._get_coding_system_prompt(),
            'debugging': self._get_debugging_system_prompt(),
            'analysis': self._get_analysis_system_prompt()
        }
        
        self.context_limit = 4096  # Default context limit for small models
        
    def optimize_for_small_model(self, prompt: str, context: Optional[List[Dict]] = None) -> List[Dict]:
        """Optimize prompt for small model constraints"""
        messages = []
        
        # Add optimized system prompt
        messages.append({
            "role": "system",
            "content": self.system_prompts['default']
        })
        
        # Add relevant context if provided
        if context:
            context_text = self._compress_context(context)
            if context_text:
                messages.append({
                    "role": "system",
                    "content": f"Context: {context_text}"
                })
        
        # Add user prompt with optimization
        optimized_prompt = self._optimize_user_prompt(prompt)
        messages.append({
            "role": "user",
            "content": optimized_prompt
        })
        
        # Ensure total length is within limits
        return self._truncate_messages(messages)
    
    def create_coding_prompt(self, task: str, language: str = "python", 
                           context: Optional[str] = None) -> List[Dict]:
        """Create optimized prompt for coding tasks"""
        messages = []
        
        # Specialized coding system prompt
        messages.append({
            "role": "system",
            "content": self.system_prompts['coding']
        })
        
        # Add context if provided
        if context:
            messages.append({
                "role": "system",
                "content": f"Code context:\n```{language}\n{context}\n```"
            })
        
        # Structured coding request
        coding_prompt = f"""
Language: {language}
Task: {task}

Please provide:
1. Code solution
2. Brief explanation
3. Usage example

Format your response clearly with code blocks.
"""
        
        messages.append({
            "role": "user",
            "content": coding_prompt.strip()
        })
        
        return self._truncate_messages(messages)
    
    def create_debugging_prompt(self, error: str, code: Optional[str] = None, 
                              context: Optional[str] = None) -> List[Dict]:
        """Create optimized prompt for debugging"""
        messages = []
        
        messages.append({
            "role": "system",
            "content": self.system_prompts['debugging']
        })
        
        debug_prompt = f"Error: {error}\n\n"
        
        if code:
            debug_prompt += f"Code:\n```\n{code}\n```\n\n"
        
        if context:
            debug_prompt += f"Context: {context}\n\n"
        
        debug_prompt += """
Provide:
1. Error explanation
2. Solution steps
3. Fixed code (if applicable)
"""
        
        messages.append({
            "role": "user",
            "content": debug_prompt.strip()
        })
        
        return self._truncate_messages(messages)
    
    def create_analysis_prompt(self, code: str, analysis_type: str = "general") -> List[Dict]:
        """Create optimized prompt for code analysis"""
        messages = []
        
        messages.append({
            "role": "system",
            "content": self.system_prompts['analysis']
        })
        
        analysis_prompt = f"""
Analysis type: {analysis_type}
Code to analyze:
```
{code}
```

Provide:
1. Code structure overview
2. Potential issues or improvements
3. Code quality assessment
"""
        
        messages.append({
            "role": "user",
            "content": analysis_prompt.strip()
        })
        
        return self._truncate_messages(messages)
    
    def create_tool_usage_prompt(self, available_tools: List[str], user_request: str) -> List[Dict]:
        """Create optimized prompt for tool usage"""
        messages = []
        
        system_prompt = f"""You are an AI coding assistant with access to these tools:
{', '.join(available_tools)}

Use tools when needed to help with the user's request. Be efficient and precise.
Format tool calls as: TOOL: tool_name(param1="value1", param2="value2")
"""
        
        messages.append({
            "role": "system", 
            "content": system_prompt
        })
        
        messages.append({
            "role": "user",
            "content": user_request
        })
        
        return messages
    
    def _get_default_system_prompt(self) -> str:
        """Get default system prompt optimized for small models"""
        return """You are AiCode, a helpful coding assistant optimized for efficiency.
- Give concise, accurate responses
- Use code examples when helpful
- Be direct and practical
- Focus on solving the immediate problem"""
    
    def _get_coding_system_prompt(self) -> str:
        """Get coding-specific system prompt"""
        return """You are AiCode, a coding assistant specialized in:
- Writing clean, efficient code
- Explaining code clearly
- Providing working examples
- Following best practices
- Being concise yet thorough"""
    
    def _get_debugging_system_prompt(self) -> str:
        """Get debugging-specific system prompt"""
        return """You are AiCode, a debugging specialist that:
- Analyzes errors systematically
- Provides step-by-step solutions
- Explains the root cause
- Offers prevention tips
- Gives working fixes"""
    
    def _get_analysis_system_prompt(self) -> str:
        """Get analysis-specific system prompt"""
        return """You are AiCode, a code analysis expert that:
- Reviews code structure and quality
- Identifies potential issues
- Suggests improvements
- Explains complexity and patterns
- Provides actionable feedback"""
    
    def _optimize_user_prompt(self, prompt: str) -> str:
        """Optimize user prompt for small models"""
        # Keep prompts concise but clear
        if len(prompt) > 500:
            # Summarize long prompts
            return f"Request: {prompt[:400]}... [Please provide a concise solution]"
        return prompt
    
    def _compress_context(self, context: Optional[List[Dict]]) -> str:
        """Compress context for small models"""
        if not context:
            return ""
        
        # Keep only recent and relevant context
        recent_context = context[-3:] if len(context) > 3 else context
        
        compressed = []
        for item in recent_context:
            if isinstance(item, dict):
                item_type = item.get('type', 'unknown')
                compressed.append(f"{item_type}: {str(item)[:100]}")
            else:
                compressed.append(str(item)[:100])
        
        return " | ".join(compressed)
    
    def _truncate_messages(self, messages: List[Dict]) -> List[Dict]:
        """Ensure messages fit within context limits"""
        total_length = sum(len(str(msg.get('content', ''))) for msg in messages)
        
        if total_length <= self.context_limit:
            return messages
        
        # Keep system message and recent user message, truncate middle
        if len(messages) > 2:
            truncated = [messages[0]]  # System message
            truncated.append(messages[-1])  # Latest user message
            return truncated
        
        return messages
