"""
Configuration management for AiCode
Handles model endpoints, settings, and user preferences
"""

import configparser
import os
from rich.console import Console
from rich.prompt import Prompt, Confirm
from rich.table import Table

console = Console()

class Config:
    def __init__(self, config_path="config.ini"):
        self.config_path = config_path
        self.config = configparser.ConfigParser()
        self.load_config()
    
    def load_config(self):
        """Load configuration from file or create default"""
        if os.path.exists(self.config_path):
            self.config.read(self.config_path)
        else:
            self.create_default_config()
    
    def create_default_config(self):
        """Create default configuration"""
        self.config['DEFAULT'] = {
            'max_tokens': '2048',
            'temperature': '0.7',
            'context_length': '4096',
            'timeout': '30'
        }
        
        self.config['models'] = {
            'default': 'http://localhost:8080/v1/chat/completions',
            'ollama': 'http://localhost:11434/api/chat',
            'lmstudio': 'http://localhost:1234/v1/chat/completions'
        }
        
        self.config['tools'] = {
            'enable_file_operations': 'true',
            'enable_terminal_commands': 'true',
            'enable_image_analysis': 'true',
            'safe_mode': 'true'
        }
        
        self.save_config()
    
    def save_config(self):
        """Save configuration to file"""
        with open(self.config_path, 'w') as f:
            self.config.write(f)
    
    def get_model_endpoint(self, model_name=None):
        """Get model endpoint URL"""
        if model_name:
            return self.config.get('models', model_name, fallback=None)
        return self.config.get('models', 'default')
    
    def get_model_config(self):
        """Get model configuration parameters"""
        return {
            'max_tokens': self.config.getint('DEFAULT', 'max_tokens'),
            'temperature': self.config.getfloat('DEFAULT', 'temperature'),
            'context_length': self.config.getint('DEFAULT', 'context_length'),
            'timeout': self.config.getint('DEFAULT', 'timeout')
        }
    
    def get_tool_config(self):
        """Get tool configuration"""
        return {
            'enable_file_operations': self.config.getboolean('tools', 'enable_file_operations'),
            'enable_terminal_commands': self.config.getboolean('tools', 'enable_terminal_commands'),
            'enable_image_analysis': self.config.getboolean('tools', 'enable_image_analysis'),
            'safe_mode': self.config.getboolean('tools', 'safe_mode')
        }
    
    def list_models(self):
        """List all configured models"""
        table = Table(title="Configured Models")
        table.add_column("Name", style="cyan")
        table.add_column("Endpoint", style="white")
        
        for name, endpoint in self.config['models'].items():
            table.add_row(name, endpoint)
        
        console.print(table)
    
    def interactive_setup(self):
        """Interactive configuration setup"""
        console.print("[bold cyan]AiCode Configuration Setup[/bold cyan]")
        
        # Model configuration
        console.print("\n[yellow]Model Configuration:[/yellow]")
        default_endpoint = Prompt.ask("Default model endpoint", 
                                    default=self.config.get('models', 'default'))
        self.config.set('models', 'default', default_endpoint)
        
        # Add additional models
        while Confirm.ask("Add another model endpoint?", default=False):
            name = Prompt.ask("Model name")
            endpoint = Prompt.ask("Model endpoint")
            self.config.set('models', name, endpoint)
        
        # General settings
        console.print("\n[yellow]General Settings:[/yellow]")
        max_tokens = Prompt.ask("Max tokens", 
                               default=str(self.config.getint('DEFAULT', 'max_tokens')))
        self.config.set('DEFAULT', 'max_tokens', max_tokens)
        
        temperature = Prompt.ask("Temperature (0.0-1.0)", 
                               default=str(self.config.getfloat('DEFAULT', 'temperature')))
        self.config.set('DEFAULT', 'temperature', temperature)
        
        # Tool settings
        console.print("\n[yellow]Tool Settings:[/yellow]")
        file_ops = Confirm.ask("Enable file operations?", 
                              default=self.config.getboolean('tools', 'enable_file_operations'))
        self.config.set('tools', 'enable_file_operations', str(file_ops))
        
        terminal_cmds = Confirm.ask("Enable terminal commands?", 
                                  default=self.config.getboolean('tools', 'enable_terminal_commands'))
        self.config.set('tools', 'enable_terminal_commands', str(terminal_cmds))
        
        image_analysis = Confirm.ask("Enable image analysis?", 
                                   default=self.config.getboolean('tools', 'enable_image_analysis'))
        self.config.set('tools', 'enable_image_analysis', str(image_analysis))
        
        safe_mode = Confirm.ask("Enable safe mode?", 
                               default=self.config.getboolean('tools', 'safe_mode'))
        self.config.set('tools', 'safe_mode', str(safe_mode))
        
        self.save_config()
